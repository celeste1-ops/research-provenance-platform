"""FSF solver v0.2 (sample code): exponent depends on F; adaptive step size."""


def alpha_of(forcing):
    return 1.5 - 0.2 * forcing


def solve(forcing, k=0.8, t_end=80.0, tol=1e-4):
    alpha = alpha_of(forcing)
    t, v, dt, out = 0.0, 0.0, 0.5, [(0.0, 0.0)]
    while t < t_end:
        full = v + dt * k * (1 - v) ** alpha
        half = v + dt / 2 * k * (1 - v) ** alpha
        half = half + dt / 2 * k * (1 - half) ** alpha
        if abs(full - half) > tol:
            dt /= 2
            continue
        t, v = t + dt, half
        out.append((t, v))
        dt = min(dt * 1.5, 2.0)
    return out
