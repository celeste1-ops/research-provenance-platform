FSF solver at commit c05b9e2 (sample code).
