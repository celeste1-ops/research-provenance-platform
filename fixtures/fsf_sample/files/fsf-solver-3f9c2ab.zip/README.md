FSF solver at commit 3f9c2ab (sample code).
