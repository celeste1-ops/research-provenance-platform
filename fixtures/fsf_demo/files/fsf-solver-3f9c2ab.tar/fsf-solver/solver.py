"""Fictional FSF demo solver (sample data, not real research)."""


def step(v, k=0.8, alpha=1.5, dt=0.1):
    return v + dt * k * (1 - v) ** alpha
